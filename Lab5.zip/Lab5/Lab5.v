module Lab5 (
    input wire clk,
    input wire S1,
    input wire S2,
    output wire X,
    output wire Y,
    output reg buzzer = 1'b1
);

    // Timing parameters (assuming a 50 MHz clock frequency)
    localparam DEBOUNCE_LIMIT = 19'd499999;     // ~10 ms debounce
    localparam BEEP_DURATION  = 22'd4000000;    // ~80 ms beep length
    localparam TONE_LIMIT     = 14'd12499;      // 2 kHz tone generator

    reg [7:0] x = 80, y = 60;
    reg [9:0] sx = 0, sy = 0;
    reg [10:0] timer = 0;
    reg [2:0] phase = 0; // 0=D, 1=A, 2=N, 3=I, 4=E, 5=L, 6=Star
    reg [3:0] segment = 0;
    reg [6:0] t = 0;

    // Button synchronization
    reg s1a = 1, s1b = 1;
    reg s2a = 1, s2b = 1;

    // Debounce logic
    reg [18:0] db1 = 0, db2 = 0;
    reg k1 = 1, k2 = 1;
    reg prev1 = 1, prev2 = 1;

    // Beep counters
    reg [13:0] tone_count = 0;
    reg [21:0] beep_count = 0;

    // Shape Coordinate Function: returns {x0, y0, x1, y1}
    function [31:0] shape;
        input [2:0] p;
        input [3:0] s;
        begin
            shape = {8'd80, 8'd60, 8'd80, 8'd60};
            case (p)
                // D
                0: case (s)
                    0: shape = {8'd70,  8'd60,  8'd70,  8'd210};
                    1: shape = {8'd70,  8'd210, 8'd110, 8'd210};
                    2: shape = {8'd110, 8'd210, 8'd140, 8'd175};
                    3: shape = {8'd140, 8'd175, 8'd140, 8'd95};
                    4: shape = {8'd140, 8'd95,  8'd110, 8'd60};
                    5: shape = {8'd110, 8'd60,  8'd70,  8'd60};
                endcase
                // A
                1: case (s)
                    0: shape = {8'd70,  8'd60,  8'd105, 8'd210};
                    1: shape = {8'd105, 8'd210, 8'd140, 8'd60};
                    2: shape = {8'd85,  8'd120, 8'd125, 8'd120};
                endcase
                // N
                2: case (s)
                    0: shape = {8'd70,  8'd60,  8'd70,  8'd210};
                    1: shape = {8'd70,  8'd210, 8'd130, 8'd60};
                    2: shape = {8'd130, 8'd60,  8'd130, 8'd210};
                endcase
                // I
                3: case (s)
                    0: shape = {8'd80,  8'd60,  8'd120, 8'd60};
                    1: shape = {8'd100, 8'd60,  8'd100, 8'd210};
                    2: shape = {8'd80,  8'd210, 8'd120, 8'd210};
                endcase
                // E
                4: case (s)
                    0: shape = {8'd120, 8'd210, 8'd70,  8'd210};
                    1: shape = {8'd70,  8'd210, 8'd70,  8'd60};
                    2: shape = {8'd70,  8'd60,  8'd120, 8'd60};
                    3: shape = {8'd70,  8'd135, 8'd110, 8'd135};
                endcase
                // L
                5: case (s)
                    0: shape = {8'd70,  8'd210, 8'd70,  8'd60};
                    1: shape = {8'd70,  8'd60,  8'd120, 8'd60};
                endcase
                // Star (Phase 6)
                6: case (s)
                    0: shape = {8'd105, 8'd75,  8'd135, 8'd180};
                    1: shape = {8'd135, 8'd180, 8'd70,  8'd110};
                    2: shape = {8'd70,  8'd110, 8'd140, 8'd110};
                    3: shape = {8'd140, 8'd110, 8'd75,  8'd180};
                    4: shape = {8'd75,  8'd180, 8'd105, 8'd75};
                endcase
            endcase
        end
    endfunction

    reg [3:0] last_segment;
    always @(*) begin
        case (phase)
            0: last_segment = 5; // D
            1: last_segment = 2; // A
            2: last_segment = 2; // N
            3: last_segment = 2; // I
            4: last_segment = 3; // E
            5: last_segment = 1; // L
            6: last_segment = 4; // Star
            default: last_segment = 0;
        endcase
    end

    wire [31:0] v = shape(phase, segment);
    wire [7:0] x0 = v[31:24];
    wire [7:0] y0 = v[23:16];
    wire [7:0] x1 = v[15:8];
    wire [7:0] y1 = v[7:0];

    wire signed [10:0] dx = $signed({1'b0, x1}) - $signed({1'b0, x0});
    wire signed [10:0] dy = $signed({1'b0, y1}) - $signed({1'b0, y0});
    wire signed [20:0] ix = $signed({1'b0, x0}) + (dx * $signed({1'b0, t})) / 63;
    wire signed [20:0] iy = $signed({1'b0, y0}) + (dy * $signed({1'b0, t})) / 63;

    wire press1 = prev1 && !k1;
    wire press2 = prev2 && !k2;

    always @(posedge clk) begin
        // Synchronize buttons
        s1a <= S1; 
        s1b <= s1a; 
        s2a <= S2; 
        s2b <= s2a;

        // Button 1 Debounce
        if (s1b == k1) 
            db1 <= 0;
        else if (db1 == DEBOUNCE_LIMIT) begin 
            db1 <= 0; 
            k1 <= s1b;
        end else 
            db1 <= db1 + 1'b1;

        // Button 2 Debounce
        if (s2b == k2) 
            db2 <= 0;
        else if (db2 == DEBOUNCE_LIMIT) begin 
            db2 <= 0; 
            k2 <= s2b;
        end else 
            db2 <= db2 + 1'b1;

        prev1 <= k1; 
        prev2 <= k2;

        // Sigma-delta DAC modulation
        sx <= {2'b00, sx[7:0]} + {2'b00, x}; 
        sy <= {2'b00, sy[7:0]} + {2'b00, y};

        // Button selection logic (Cycles through phases 0 to 6)
        if (press1 || press2) begin
            if (press1)
                phase <= (phase == 6) ? 0 : phase + 1'b1;
            else 
                phase <= (phase == 0) ? 6 : phase - 1'b1;
            
            segment <= 0; 
            t <= 0;
            timer <= 0; 
            
            // Trigger buzzer beep
            beep_count <= BEEP_DURATION; 
            tone_count <= 0; 
            buzzer <= 1'b1;
        end else begin 
            // Drawing engine step timer
            if (timer == 1388) begin
                timer <= 0;
                x <= ix[7:0]; 
                y <= iy[7:0];
                if (t == 63) begin 
                    t <= 0;
                    segment <= (segment == last_segment) ? 0 : segment + 1'b1;
                end else 
                    t <= t + 1'b1; 
            end else 
                timer <= timer + 1'b1; 

            // Buzzer oscillator tone generator
            if (beep_count != 0) begin
                beep_count <= beep_count - 1'b1; 
                if (tone_count == TONE_LIMIT) begin
                    tone_count <= 0; 
                    buzzer <= ~buzzer;
                end else 
                    tone_count <= tone_count + 1'b1; 
            end else begin
                // Inactive buzzer state = HIGH
                buzzer <= 1'b1; 
                tone_count <= 0;
            end 
        end
    end

    assign X = sx[8];
    assign Y = sy[8];

endmodule