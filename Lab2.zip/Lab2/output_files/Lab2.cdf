/* Quartus Prime Version 25.1std.0 Build 1129 10/21/2025 SC Lite Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Ign)
		Device PartName(EP4CE10E22) MfrSpec(OpMask(0) FullPath("C:/Users/instalare/AppData/Local/quartus/Lab2/output_files/Lab2.sof"));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
